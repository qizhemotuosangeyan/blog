

import CoreML
import Vision

print("Hello, World!")
//首先初始化模型
let royeModel = RoleClassfier_1.init().model
//用自己的模型初始化model
let model = try VNCoreMLModel(for: RoleClassfier_1().model)
//定义响应函数
let request = VNCoreMLRequest(model: model, completionHandler: myResultsMethod)

let handler = VNImageRequestHandler(url:URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSTaRprTV98Fhvd2uwiZ2-ZaYE-jt4QY7I6bg&usqp=CAU")!)
try handler.perform([request])

/// 实现响应函数
/// - Parameters:
///   - request: 响应闭包
///   - error: 错误闭包
func myResultsMethod(request: VNRequest, error: Error?) {
    guard let results = request.results as? [VNClassificationObservation]
        else { fatalError("huh") }
    for classification in results {
        print(classification.identifier, // the scene label
              classification.confidence)
    }

}
//这里来自https://www.coder.work/article/252416
